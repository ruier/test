/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ALPHA_NUMERIC_WORD = 258,
     JMP = 259,
     COLON = 260,
     NOP = 261,
     CONFIRM_LAYER_MASK = 262,
     START_RAW_INSTRUCTION = 263,
     HEX_WORD = 264,
     HEX_VALUE = 265,
     ASSIGN = 266,
     INCREMENT = 267,
     WINDOW_OFFSET = 268,
     HEADER_BASE = 269,
     RETURN = 270,
     SET_BITS = 271,
     LCV = 272,
     START_RESULT_ARRAY = 273,
     RIGHT_BRACKET = 274,
     ETH_HXS = 275,
     IPV4_HXS = 276,
     IPV6_HXS = 277,
     OTH_L3_HXS = 278,
     TCP_HXS = 279,
     UDP_HXS = 280,
     OTH_L4_HXS = 281,
     RETURN_HXS = 282,
     END_PARSE = 283,
     CONCAT = 284,
     WR0 = 285,
     WR1 = 286,
     CLEAR = 287,
     ONESCOMP = 288,
     AND = 289,
     OR = 290,
     XOR = 291,
     SHIFT_LEFT = 292,
     SHIFT_RIGHT = 293,
     IF = 294,
     START_FRAME_WINDOW = 295,
     QUESTION = 296,
     PIPE = 297,
     AMPERSAND = 298,
     HXS = 299,
     BRIDGE = 300,
     START_PARAMETER_ARRAY = 301,
     EQUAL = 302,
     NOT_EQUAL = 303,
     GREATER_THAN = 304,
     LESS_THAN = 305,
     GREATER_THAN_EQUAL = 306,
     LESS_THAN_EQUAL = 307,
     OPEN_PAREN = 308,
     CLOSE_PAREN = 309,
     COMMA = 310,
     CONTEXT_LIST = 311,
     PLUS = 312,
     MINUS = 313,
     NXT_ETH_TYPE = 314,
     NXT_IP_PROTO = 315,
     UINT6_TYPE = 316,
     UINT7_TYPE = 317,
     UINT8_TYPE = 318,
     UINT16_TYPE = 319,
     UINT32_TYPE = 320,
     UINT48_TYPE = 321,
     UINT64_TYPE = 322,
     DEC_VALUE = 323
   };
#endif
/* Tokens.  */
#define ALPHA_NUMERIC_WORD 258
#define JMP 259
#define COLON 260
#define NOP 261
#define CONFIRM_LAYER_MASK 262
#define START_RAW_INSTRUCTION 263
#define HEX_WORD 264
#define HEX_VALUE 265
#define ASSIGN 266
#define INCREMENT 267
#define WINDOW_OFFSET 268
#define HEADER_BASE 269
#define RETURN 270
#define SET_BITS 271
#define LCV 272
#define START_RESULT_ARRAY 273
#define RIGHT_BRACKET 274
#define ETH_HXS 275
#define IPV4_HXS 276
#define IPV6_HXS 277
#define OTH_L3_HXS 278
#define TCP_HXS 279
#define UDP_HXS 280
#define OTH_L4_HXS 281
#define RETURN_HXS 282
#define END_PARSE 283
#define CONCAT 284
#define WR0 285
#define WR1 286
#define CLEAR 287
#define ONESCOMP 288
#define AND 289
#define OR 290
#define XOR 291
#define SHIFT_LEFT 292
#define SHIFT_RIGHT 293
#define IF 294
#define START_FRAME_WINDOW 295
#define QUESTION 296
#define PIPE 297
#define AMPERSAND 298
#define HXS 299
#define BRIDGE 300
#define START_PARAMETER_ARRAY 301
#define EQUAL 302
#define NOT_EQUAL 303
#define GREATER_THAN 304
#define LESS_THAN 305
#define GREATER_THAN_EQUAL 306
#define LESS_THAN_EQUAL 307
#define OPEN_PAREN 308
#define CLOSE_PAREN 309
#define COMMA 310
#define CONTEXT_LIST 311
#define PLUS 312
#define MINUS 313
#define NXT_ETH_TYPE 314
#define NXT_IP_PROTO 315
#define UINT6_TYPE 316
#define UINT7_TYPE 317
#define UINT8_TYPE 318
#define UINT16_TYPE 319
#define UINT32_TYPE 320
#define UINT48_TYPE 321
#define UINT64_TYPE 322
#define DEC_VALUE 323




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 5542 ".\\spa\\fm_sp_assembler.y"
{
          int   integer;
          char *string;
       }
/* Line 1489 of yacc.c.  */
#line 190 "spa/fm_sp_assembler.tab.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



